const jwt = require('jsonwebtoken');
const {supabase} = require("./supabase");


exports.handler = async (event) => {
    let body = JSON.parse(event.body);
    const randomNonce = Math.floor(Math.random() * 1000000);
    try {
        const {token, wallet} = body;
        const validateToken = await jwt.verify(token, 'secret');
        if (validateToken) {
            await supabase
                .from("auth")
                .update({ nonce: randomNonce })
                .select("nonce")
                .eq("wallet", wallet);
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({validateToken})
            }
        } else {
            return {
                statusCode: 400,
                body: 'Invalid token: authentication failed'
            }
        }
    } catch (err) {
        return {
            statusCode: 400,
            body: err.message
        }
    }
}
