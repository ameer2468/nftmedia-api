const jwt = require('jsonwebtoken');


exports.handler = (event) => {
    let body = JSON.parse(event.body);
    try {
        const {address, signature, nonce} = body;
        const generateToken = jwt.sign({address, nonce, signature}, 'secret');
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({token: generateToken})
        }
    } catch (err) {
        return {
            statusCode: 400,
            body: err.message
        }
    }
}
